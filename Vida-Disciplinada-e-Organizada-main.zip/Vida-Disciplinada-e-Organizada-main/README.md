# Vida-Disciplinada-e-Organizada
Trabalho de Projeto Integrador sobre Vida Disciplinada e Organizada.
